PadExtend 一体化安装即用包（托盘后台版 / USB）
================================================

把 Windows 虚拟扩展屏实时推流到 Android 平板。推流在后台运行，桌面无黑框，
只在任务栏托盘有一个图标。

【PC 端：双击即用】
1. 用 USB 线把平板连到电脑，平板上允许 USB 调试（小米还需开"USB 安装"）。
2. 双击 PadExtend.exe（弹一次 UAC，点"是"）。
3. 程序在后台自动完成：装 VDD 驱动(首次) -> 建 1920x1080 虚拟扩展屏 ->
   给平板装客户端 APK(首次) -> 建立 USB 通道 -> 启动推流。
4. 任务栏右下角出现 PadExtend 托盘图标。把窗口拖到最右侧那块虚拟屏，
   平板上会实时显示。

【托盘图标（右键）】
- 状态：显示当前运行状态。
- 重启推流：重新跑一遍编排。
- 退出：停止推流并退出。

【说明】
- 平板请保持 PadExtend 应用在前台，不要下拉通知栏或锁屏，否则画面暂停。
- 虚拟屏空白静止时帧率低属正常，放上有内容的窗口即流畅。
- 换数据线/重插 USB 后若没画面，托盘右键"重启推流"或重新双击 exe 即可。

【目录结构】
  PadExtend.exe          托盘启动器（以管理员运行，无黑框）
  payload\vdd\           VDD 虚拟显示驱动 + nefconc（均已签名）
  payload\adb\           adb 及依赖
  payload\sender\        推流发送端（自包含）
  payload\app\           Android 客户端 APK

【高级：手动启动发送端】
  payload\sender\PadExtend.Sender.exe --source=duplication --output=-1 --fps=30 --bitrate=8000000
  （需先 adb reverse tcp:27555 tcp:27555）
  --output=-1 自动选最后接入的显示输出（通常是虚拟屏）。

【签名与来源】
- VDD 驱动：SignPath Foundation / GlobalSign 签名，x64 普通机器免测试模式直接装。
  https://github.com/VirtualDrivers/Virtual-Display-Driver (MIT)
- nefcon 工具：Nefarius 签名。 https://github.com/nefarius/nefcon
- Android release 版如需上架需自行用 apksigner 签名；包内为 debug 签名版。
