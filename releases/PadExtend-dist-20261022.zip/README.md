# PadExtend 分发包

构建时间：2026-10-22

本目录包含 PadExtend（Windows 虚拟扩展屏 → Android 平板实时推流）三个可部署组件。

## 目录结构

- windows/PadExtend.Sender/ — Windows 发送端（.NET 9 自包含 win-x64）。
  - PadExtend.Sender.exe 可执行文件，已随包含 PadExtend.Encoder.dll（Media Foundation H.264 编码器）。
  - 自包含发布，目标机无需安装 .NET 运行时。
- android/ — Android 接收端 APK。
  - PadExtend.Client-debug.apk（已用 debug 证书签名，可直接 adb install）。
  - PadExtend.Client-release-unsigned.apk（release 未签名，需自行用 apksigner 签名后安装）。
- driver/ — IDD 间接显示驱动（UMDF，WDKTestCert 测试签名）。
  - IddSampleDriver/：IddSampleDriver.inf / .dll / .cat 驱动包。
  - IddSampleApp.exe：创建/移除虚拟显示设备的测试工具。

## 部署与运行

### 1. 安装 IDD 驱动（PC，管理员）

驱动为测试签名，需先开启测试模式并重启：

    bcdedit /set testsigning on

安装驱动（在 driver/IddSampleDriver 目录）：

    pnputil /add-driver IddSampleDriver.inf /install

用 IddSampleApp.exe 创建虚拟显示设备。

### 2. Android 端

    adb install -r PadExtend.Client-debug.apk

release 版为未签名包，发布前需签名：

    apksigner sign --ks <your.keystore> PadExtend.Client-release-unsigned.apk

### 3. 建立 USB 通道并启动发送端（PC）

    adb reverse tcp:27555 tcp:27555
    PadExtend.Sender.exe --port=27555 --fps=30 --bitrate=8000000

Sender 默认从 C:\ProgramData\PadExtend\frame.bmp 读取驱动写出的帧，经 H.264 编码后按协议 v1.1 通过 TCP 127.0.0.1:27555 发送，由 adb reverse 走 USB 到 Android 客户端。

## 备注

- Sender 发布时有 1 条无害告警（CA1416，EventWaitHandle.OpenExisting 仅 Windows 支持），本项目仅在 Windows 运行，无影响。
- Android 使用 compileSdk 35 / AGP 8.5.2，构建时有 compileSdk 版本提示，不影响产物。
- 驱动使用 WDKTestCert 测试签名，仅用于开发/测试环境；正式分发需用 EV 证书并提交 WHQL。
